﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp.Areas.PMModule.Models
{
    [Serializable]
    public class Equipment
    {
        public int id { get; set; }

        public string name { get; set; }

        public Equipment(int Id1, string Name1)
        {
            this.id = Id1;
            this.name = Name1;
        }


    }
}