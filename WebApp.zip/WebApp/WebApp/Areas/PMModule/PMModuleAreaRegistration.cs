﻿using System.Web.Mvc;

namespace WebApp.Areas.PMModule
{
    public class PMModuleAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "PMModule";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "PMModule_default",
                "PMModule/{action}/{id}",
                new { action = "ShowAll", id = UrlParameter.Optional }
            );
            
        }
    }
}