﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApp.Areas.PMModule.Models;

namespace WebApp.Areas.PMModule.Controllers
{
    public class EquipmentController : ApiController
    {
        [Route("api/PMModule/default")]
        [HttpGet]
        public List<Equipment>  ShowAll()
         {
            
            Equipment e1 = new Equipment(101, "John Deere");
            Equipment e2 = new Equipment(102, "Massey Ferguson");

            List<Equipment> retVal = new List<Equipment>();
            retVal.Add(e1);
            retVal.Add(e2);

            return retVal;
        }

        [Route("api/PMModule/Search/")]
        [HttpGet]
        public List<Equipment> Search(int eid)
        {
            Equipment e1 = new Equipment(101, "John Deere");
            Equipment e2 = new Equipment(102, "Massey Ferguson");

            List<Equipment> retVal = new List<Equipment>();
            retVal.Add(e1);
            retVal.Add(e2);

            return retVal.Where(x => x.id == eid).ToList<Equipment>();
        }
    }
}